export default {
  webWorkerManager: {
    initialize: jest.fn(),
  },
};
