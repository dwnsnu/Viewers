// https://jestjs.io/docs/en/webpack#handling-static-assets

module.exports = 'test-file-stub';
