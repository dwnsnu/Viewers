// "export default '"$(git rev-parse HEAD)"';"
