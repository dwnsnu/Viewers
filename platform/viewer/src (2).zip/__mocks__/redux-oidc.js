const createUserManager = () => jest.fn().mockReturnValue({});
const loadUser = () => jest.fn();

export { createUserManager, loadUser };
