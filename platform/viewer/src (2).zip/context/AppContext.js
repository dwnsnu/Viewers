import React from 'react';

let AppContext = React.createContext({});

export default AppContext;
